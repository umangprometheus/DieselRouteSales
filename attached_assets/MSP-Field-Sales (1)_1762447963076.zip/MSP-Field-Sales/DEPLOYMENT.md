# VM Deployment Guide

This guide covers deploying the MSP Diesel Field Sales Route App to a Linux VM with your own PostgreSQL database.

---

## Prerequisites

- Ubuntu 20.04+ or similar Linux distribution
- Root or sudo access
- PostgreSQL 12+ installed
- Node.js 20+ installed
- Nginx (recommended for reverse proxy)
- PM2 (recommended for process management)

---

## Quick Start (For the Impatient)

```bash
# 1. Setup PostgreSQL
sudo -u postgres psql -c "CREATE DATABASE field_sales;"
sudo -u postgres psql -c "CREATE USER field_sales_user WITH PASSWORD 'your_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE field_sales TO field_sales_user;"

# 2. Clone code and install
cd /var/www/field-sales-app
npm install

# 3. Configure environment
cp .env.example .env
nano .env  # Edit with your values

# 4. Initialize database
npm run db:push

# 5. Build and start
npm run build
npm install -g pm2
pm2 start dist/index.js --name field-sales-app
pm2 save
pm2 startup
```

**Done!** App running on http://localhost:5000

For production setup with Nginx and SSL, continue reading...

---

## Step 1: Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20 (if not installed)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL (if not installed)
sudo apt install -y postgresql postgresql-contrib

# Install Nginx (optional, recommended)
sudo apt install -y nginx

# Install PM2 globally
sudo npm install -g pm2

# Install build tools
sudo apt install -y build-essential git
```

---

## Step 2: Setup PostgreSQL Database

```bash
# Switch to postgres user
sudo -u postgres psql

# Inside PostgreSQL shell:
CREATE DATABASE field_sales;
CREATE USER field_sales_user WITH PASSWORD 'your_secure_password_here';
GRANT ALL PRIVILEGES ON DATABASE field_sales TO field_sales_user;

# Enable UUID extension
\c field_sales
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For text search performance

# Exit PostgreSQL
\q
```

**Note:** Save your database credentials - you'll need them for the `.env` file.

---

## Step 3: Clone and Setup Application

```bash
# Create application directory
sudo mkdir -p /var/www/field-sales-app
sudo chown $USER:$USER /var/www/field-sales-app
cd /var/www/field-sales-app

# Clone or copy your code here
# Option 1: Git clone
git clone <your-repo-url> .

# Option 2: Copy from local machine
# scp -r /path/to/local/code/* user@server:/var/www/field-sales-app/

# Install dependencies
npm install
```

---

## Step 4: Configure Environment Variables

```bash
# Copy example env file
cp .env.example .env

# Edit .env with your actual values
nano .env
```

**Minimum required configuration:**

```bash
DATABASE_URL=postgresql://field_sales_user:your_secure_password@localhost:5432/field_sales
HUBSPOT_API_KEY=pat-na1-your-hubspot-api-key-here
MAPBOX_TOKEN=pk.your_mapbox_token_here
VITE_MAPBOX_TOKEN=pk.your_mapbox_token_here
SESSION_SECRET=$(openssl rand -hex 32)
NODE_ENV=production
PORT=5000
```

**To generate a secure session secret:**
```bash
openssl rand -hex 32
```

**Security: Protect your .env file**
```bash
chmod 600 .env
echo ".env" >> .gitignore
```

---

## Step 5: Switch to Standard PostgreSQL Driver

The codebase includes both Neon (for Replit) and standard PostgreSQL (for VMs) configurations. You need to swap the database file:

```bash
# Backup original Neon version (optional)
mv server/db.ts server/db.neon.ts

# Use the VM-optimized version
mv server/db.vm.ts server/db.ts
```

**What this does:**
- Switches from `@neondatabase/serverless` to standard `pg` driver
- Enables connection pooling (configurable via .env)
- Works with any PostgreSQL 12+ database

## Step 6: Initialize Database Schema

```bash
# Push schema to database
npm run db:push

# If you get data-loss warnings (first deployment), force it:
npm run db:push -- --force
```

This creates all tables, indexes, and constraints defined in `shared/schema.ts`.

**Expected output:**
```
✓ Pulling schema from database...
✓ Changes applied
```

---

## Step 7: Build Application

```bash
# Build frontend and backend
npm run build

# This creates:
# - dist/index.js - Bundled backend server
# - dist/public/ - Static frontend assets
```

**Verify build:**
```bash
ls -la dist/
# Should see index.js and public/ directory
```

---

## Step 8: Test Before Production

```bash
# Start app manually to test
npm start

# In another terminal, test the API
curl http://localhost:5000/api/auth/me
# Expected: {"error":{"code":"UNAUTHORIZED","message":"Not authenticated"}}

# Test frontend
curl http://localhost:5000
# Expected: HTML content

# If everything works, press Ctrl+C to stop
```

---

## Step 9: Setup PM2 Process Manager

Create PM2 ecosystem file for better process management:

```bash
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'field-sales-app',
    script: './dist/index.js',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    max_memory_restart: '500M',
  }]
};
EOF

# Create logs directory
mkdir -p logs

# Start application with PM2
pm2 start ecosystem.config.js

# Verify it's running
pm2 status

# Save PM2 process list
pm2 save

# Setup PM2 to start on system boot
pm2 startup
# Follow the instructions shown (will give you a sudo command to run)
```

**PM2 Commands:**
```bash
pm2 status              # Check app status
pm2 logs field-sales-app # View logs
pm2 restart field-sales-app # Restart app
pm2 stop field-sales-app    # Stop app
pm2 monit               # Real-time monitoring
```

---

## Step 10: Configure Nginx Reverse Proxy (Recommended)

```bash
# Create Nginx config
sudo nano /etc/nginx/sites-available/field-sales-app
```

**Add this configuration:**

```nginx
server {
    listen 80;
    server_name your-domain.com;  # Replace with your domain or IP

    # Increase max body size for uploads
    client_max_body_size 10M;

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    # Frontend static files
    location / {
        root /var/www/field-sales-app/dist/public;
        try_files $uri $uri/ /index.html;
        
        # Cache static assets
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }

    # API proxy to Express backend
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Increase timeouts for long requests
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # WebSocket support (if needed for future features)
    location /ws {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

**Enable the site:**

```bash
# Link config to enabled sites
sudo ln -s /etc/nginx/sites-available/field-sales-app /etc/nginx/sites-enabled/

# Test Nginx configuration
sudo nginx -t

# If test passes, restart Nginx
sudo systemctl restart nginx

# Check Nginx status
sudo systemctl status nginx
```

---

## Step 11: Setup SSL with Let's Encrypt (Recommended)

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d your-domain.com

# Certbot will automatically update your Nginx config for HTTPS

# Test auto-renewal
sudo certbot renew --dry-run
```

After SSL setup, your app will be available at `https://your-domain.com`

---

## Step 12: Create Demo User (Optional)

The app auto-creates a demo user on first startup. If you need to create users manually:

```bash
# Install bcryptjs CLI
npm install -g bcryptjs-cli

# Generate password hash
echo -n "demo123" | bcryptjs-cli hash

# Connect to database
psql postgresql://field_sales_user:your_password@localhost:5432/field_sales

# Create user (replace hash with output from above)
INSERT INTO users (id, username, password_hash, email, name, hubspot_owner_id)
VALUES (
  gen_random_uuid(),
  'demo',
  '$2a$10$your_bcrypt_hash_here',
  'demo@example.com',
  'Demo User',
  NULL  -- NULL means user sees all companies
);

# Exit
\q
```

---

## Verify Deployment

```bash
# Check PM2 status
pm2 status

# View application logs
pm2 logs field-sales-app --lines 50

# Test API endpoint
curl http://localhost:5000/api/auth/me
# Expected: {"error":{"code":"UNAUTHORIZED"}}

# Test frontend (with Nginx)
curl http://your-domain.com
# Expected: HTML content

# Test HTTPS (if SSL configured)
curl https://your-domain.com
```

---

## Maintenance

### Update Application

```bash
cd /var/www/field-sales-app

# Pull latest code
git pull

# Install new dependencies (if any)
npm install

# Rebuild
npm run build

# Restart application
pm2 restart field-sales-app

# Check logs for errors
pm2 logs field-sales-app
```

### Database Migrations

```bash
# After schema changes, push to database
npm run db:push

# If data-loss warning, force push
npm run db:push -- --force
```

### View Logs

```bash
# Application logs
pm2 logs field-sales-app

# Or view raw log files
tail -f logs/out.log
tail -f logs/err.log

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

### Backup Database

```bash
# Create backup
pg_dump -U field_sales_user field_sales > backup_$(date +%Y%m%d).sql

# Compress backup
gzip backup_$(date +%Y%m%d).sql

# Restore from backup
gunzip backup_20251028.sql.gz
psql -U field_sales_user field_sales < backup_20251028.sql
```

---

## Automated Backups

```bash
# Create backup script
sudo nano /usr/local/bin/backup-field-sales.sh
```

**Add this content:**

```bash
#!/bin/bash
BACKUP_DIR="/var/backups/field-sales"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup database
pg_dump -U field_sales_user field_sales | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# Backup .env file
cp /var/www/field-sales-app/.env $BACKUP_DIR/env_$DATE

# Delete backups older than 30 days
find $BACKUP_DIR -type f -mtime +30 -delete

echo "Backup completed: $DATE"
```

**Make executable and schedule:**

```bash
# Make executable
sudo chmod +x /usr/local/bin/backup-field-sales.sh

# Add to crontab (daily at 2 AM)
(crontab -l 2>/dev/null; echo "0 2 * * * /usr/local/bin/backup-field-sales.sh") | crontab -

# Verify crontab
crontab -l
```

---

## Firewall Configuration

```bash
# Allow HTTP and HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Allow SSH (if not already)
sudo ufw allow 22/tcp

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

---

## Troubleshooting

### Database Connection Issues

```bash
# Test PostgreSQL connection
psql postgresql://field_sales_user:password@localhost:5432/field_sales

# Check if PostgreSQL is running
sudo systemctl status postgresql

# Restart PostgreSQL
sudo systemctl restart postgresql

# Check PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

### App Won't Start

```bash
# Check PM2 logs
pm2 logs field-sales-app --lines 100

# Check if .env file exists
ls -la .env

# Verify environment variables are loaded
pm2 show field-sales-app

# Check if port 5000 is available
sudo lsof -i :5000

# Manually run to see errors
npm start
```

### Nginx Issues

```bash
# Test Nginx config
sudo nginx -t

# Check Nginx status
sudo systemctl status nginx

# Restart Nginx
sudo systemctl restart nginx

# Check error logs
sudo tail -f /var/log/nginx/error.log
```

### Build Fails

```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Clear build cache
rm -rf dist/

# Try building again
npm run build
```

---

## Performance Tuning

### PostgreSQL Optimization

Edit `/etc/postgresql/*/main/postgresql.conf`:

```ini
# Memory settings (adjust for your server RAM)
shared_buffers = 256MB
effective_cache_size = 1GB
maintenance_work_mem = 64MB
work_mem = 16MB

# Checkpoint settings
checkpoint_completion_target = 0.9
wal_buffers = 16MB
min_wal_size = 1GB
max_wal_size = 4GB

# Connection settings
max_connections = 100

# Query planner
default_statistics_target = 100
random_page_cost = 1.1
effective_io_concurrency = 200
```

**Apply changes:**
```bash
sudo systemctl restart postgresql
```

### PM2 Cluster Mode (Multi-Core)

Edit `ecosystem.config.js`:

```javascript
instances: 'max',  // Use all CPU cores
exec_mode: 'cluster',
```

**Restart:**
```bash
pm2 restart field-sales-app
```

---

## Security Checklist

- [ ] Strong database password set
- [ ] Random SESSION_SECRET generated (32+ bytes)
- [ ] `.env` file has 600 permissions (`chmod 600 .env`)
- [ ] SSL certificate installed (HTTPS)
- [ ] Firewall configured (UFW enabled)
- [ ] PostgreSQL only listens on localhost
- [ ] Regular backups configured (crontab)
- [ ] System updates automated (`apt install unattended-upgrades`)
- [ ] Fail2ban installed (optional but recommended)
- [ ] Monitoring/alerting setup (optional)

---

## Monitoring

### Setup Basic Monitoring

```bash
# Install htop for resource monitoring
sudo apt install -y htop

# View real-time resources
htop

# Check disk usage
df -h

# Check memory usage
free -h

# Check PostgreSQL stats
psql -U field_sales_user field_sales -c "SELECT * FROM pg_stat_activity;"
```

### Log Rotation

PM2 handles log rotation automatically, but you can configure it:

```bash
pm2 install pm2-logrotate

# Configure (optional)
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 30
```

---

## Cost Comparison

| Component | Replit | DigitalOcean | AWS EC2 | Linode |
|-----------|--------|--------------|---------|--------|
| **Hosting** | $6-60/mo | $12/mo (2GB) | $13/mo (t3.small) | $12/mo (2GB) |
| **Database** | $0 (Neon) | $0 (self-hosted) | $15/mo (RDS) | $0 (self-hosted) |
| **Total** | $6-60/mo | **$12/mo** | $28/mo | **$12/mo** |

**Recommended:** DigitalOcean or Linode $12/mo droplet with self-hosted PostgreSQL

---

## Support Resources

**Official Documentation:**
- [PostgreSQL Docs](https://www.postgresql.org/docs/)
- [PM2 Docs](https://pm2.keymetrics.io/)
- [Nginx Docs](https://nginx.org/en/docs/)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)

**Project Documentation:**
- `PROJECT_CONTEXT.md` - Complete project overview
- `HUBSPOT_CUSTOM_OBJECT_SETUP.md` - HubSpot integration
- `design_guidelines.md` - UI/UX standards
- `.env.example` - Environment variables reference

---

## Common Commands Reference

```bash
# Application
pm2 start field-sales-app
pm2 stop field-sales-app
pm2 restart field-sales-app
pm2 logs field-sales-app
pm2 monit

# Database
npm run db:push              # Sync schema
pg_dump -U user db > backup.sql  # Backup
psql -U user db < backup.sql     # Restore

# Nginx
sudo nginx -t                # Test config
sudo systemctl restart nginx # Restart
sudo tail -f /var/log/nginx/error.log

# System
sudo systemctl status postgresql
htop
df -h
free -h
```

---

**Deployment Guide Version:** 1.0  
**Last Updated:** October 28, 2025  
**Tested On:** Ubuntu 22.04 LTS

For questions or issues, refer to `PROJECT_CONTEXT.md` for architectural details.
