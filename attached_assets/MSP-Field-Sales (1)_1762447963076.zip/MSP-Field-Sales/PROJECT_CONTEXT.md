# MSP Diesel Field Sales Route App - Project Context

**Last Updated:** October 28, 2025  
**Status:** Production-ready with AI voice feature planned

---

## Project Overview

A Progressive Web App (PWA) for field sales route planning and customer check-ins with real-time GPS tracking and HubSpot CRM integration. Built for MSP Diesel sales reps who visit multiple customer locations daily.

**Core Value Proposition:**
- Plan optimized multi-stop routes based on proximity
- Auto-detect customer arrivals within 800 feet
- Log field visits directly to HubSpot CRM
- Track daily metrics (visits, miles, duration)
- Mobile-first design for outdoor use

---

## Architecture Decisions

### Authentication Model
- **Username/password** (not HubSpot OAuth)
- Session-based with bcrypt password hashing
- Each user mapped to HubSpot owner via `hubspotOwnerId` field
- Cookie-based sessions stored in PostgreSQL

**Why not OAuth?**
- Simpler deployment (single API key vs. OAuth flow)
- Reps don't need HubSpot accounts
- Better for field service context

### Database Strategy
- **PostgreSQL** (was in-memory, migrated Oct 2025)
- **Works with any PostgreSQL 12+** (Neon, self-hosted, RDS, etc.)
- **Drizzle ORM** for type-safe queries
- **Relational + JSONB** hybrid:
  - `route_stops` table for analytics
  - Legacy `routes.stops` JSONB for backward compatibility

### HubSpot Integration
- **Private App API** (not connector)
- Background sync every 15 minutes (1,707 companies)
- Check-ins attempt custom object, fall back to Notes
- Owner-based filtering (reps see only their companies)

### Mapbox Services
- **Geocoding:** One-time per company, cached forever
- **Route Optimization:** On-demand when building routes
- **Map Display:** Client-side rendering

### Distance Units
- **All calculations in meters** (Mapbox/Turf.js standard)
- **All displays in US imperial:**
  - < 0.5 miles → feet (e.g., "1,200 ft")
  - ≥ 0.5 miles → miles (e.g., "2.4 mi")
- **Proximity threshold:** 800 feet (~243.84 meters)

---

## API Usage & Costs

### Current Free Tier Usage (as of Oct 28, 2025)

| **Service** | **Usage** | **Free Limit** | **% Used** | **Cost** |
|------------|-----------|----------------|------------|----------|
| Mapbox Geocoding | 3,099 | 100,000/month | 3.1% | $0 |
| Mapbox Route Optimization | 19 | 100,000/month | 0.02% | $0 |
| Mapbox Map Loads | 199 | 50,000/month | 0.4% | $0 |
| HubSpot API | ~1,600/day | 250,000/day | 0.6% | $0 |

**Projected Costs at Scale (10 reps, 5 stops/day):**
- Mapbox: Still $0/month (well within free tier)
- HubSpot: Still $0/month (free tier sufficient)
- **Total: $0/month** until hitting massive scale

### Why Geocoding is High but Safe
- **3,099 requests = one-time setup cost**
- Geocodes cached in PostgreSQL forever
- Future usage: ~50-100/month (only new companies)
- Smart caching prevents re-geocoding

---

## Key Features Implemented

### ✅ Route Planning
- Interactive Mapbox GL map with company markers
- Filter by radius (5-100 miles)
- Search by company name
- Multi-select companies
- Automatic route optimization (traveling salesman)
- Google Maps navigation integration

### ✅ Route Execution
- Real-time GPS tracking (3-second polling)
- Proximity alerts at 800 feet
- Check-in logging with GPS coordinates
- Add/skip stops mid-route
- Manual route completion
- Automatic completion when all stops done

### ✅ Daily Summary
- Total visits, miles, duration
- Company details with timestamps
- CSV export
- Date picker for historical views

### ✅ HubSpot Sync
- Background job every 15 minutes
- Incremental updates (only new/changed companies)
- Owner-based filtering
- Check-in logging to custom object or Notes

### ✅ Mobile Optimization
- 44px minimum touch targets (safety)
- Bottom sheet UI for route info
- No backdrop on map (tap-through to markers)
- High contrast colors for outdoor visibility

---

## Tech Stack

**Frontend:**
- React 18 + Vite
- Wouter (routing)
- TanStack Query v5 (caching)
- Shadcn UI + Tailwind CSS
- Mapbox GL JS
- Turf.js (geospatial)

**Backend:**
- Node.js 20 + Express
- PostgreSQL + Drizzle ORM
- HubSpot API Client
- Express-session + bcrypt
- Node-cron (background jobs)

**Infrastructure:**
- Replit (development)
- PostgreSQL (any provider)
- Mapbox APIs
- HubSpot Private App

---

## Database Schema

```typescript
// users - Authentication & owner mapping
{
  id: uuid (PK)
  username: string (unique)
  passwordHash: string (bcrypt)
  email: string | null
  name: string | null
  hubspotOwnerId: string | null  // Maps to HubSpot owner
}

// companies - Cached from HubSpot with geocoding
{
  id: string (PK, HubSpot company ID)
  name: string
  street: string | null
  city: string | null
  state: string | null
  postalCode: string | null
  country: string | null
  lat: decimal | null  // Geocoded coordinates
  lng: decimal | null
  ownerId: string | null  // HubSpot owner ID
}

// routes - Planned routes
{
  id: uuid (PK)
  userId: uuid (FK → users)
  stops: jsonb  // Legacy: [{companyId, name, lat, lng, ...}]
  totalDistMi: decimal
  totalEtaMin: decimal
  navUrl: string  // Google Maps URL
  startedAt: timestamp | null
  completedAt: timestamp | null
}

// route_stops - Relational route analytics
{
  id: uuid (PK)
  routeId: uuid (FK → routes)
  companyId: string (FK → companies)
  sequence: integer  // Stop order (0-based)
  distanceFromPrevMi: decimal
  etaFromPrevMin: decimal
  completed: boolean
  completedAt: timestamp | null
  UNIQUE(routeId, companyId)  // Prevent duplicates
}

// check_ins - Field visit logs
{
  id: uuid (PK)
  userId: uuid (FK → users)
  routeId: uuid | null (FK → routes)
  companyId: string (FK → companies)
  lat: decimal
  lng: decimal
  notes: string | null
  timestamp: timestamp (default now)
  hubspotCheckInId: string | null  // HubSpot field_visit ID
}

// sync_logs - Background sync tracking
{
  id: uuid (PK)
  startedAt: timestamp
  completedAt: timestamp | null
  companiesSynced: integer
  error: string | null
}
```

---

## Key Design Patterns

### Smart Geocoding Cache
```typescript
// Only geocode if coordinates missing
const existing = await storage.getCompany(companyId);
if (!existing?.lat || !existing?.lng) {
  const coords = await geocodeAddress(address);
  // Cache forever in PostgreSQL
}
```

### Owner-Based Filtering
```typescript
// Reps see only their companies
WHERE companies.ownerId = user.hubspotOwnerId
// Admins (no hubspotOwnerId) see all
WHERE user.hubspotOwnerId IS NULL OR companies.ownerId = user.hubspotOwnerId
```

### Graceful HubSpot Fallback
```typescript
try {
  await createFieldVisitCheckIn(data);
} catch (error) {
  // Custom object doesn't exist - use Notes instead
  await createNote(companyId, checkInData);
}
// Still save to local database regardless
```

### Distance Formatting
```typescript
function formatDistance(meters: number): string {
  const miles = meters / 1609.34;
  if (miles < 0.5) {
    return `${Math.round(meters * 3.28084)} ft`;
  }
  return `${miles.toFixed(1)} mi`;
}
```

---

## Recent Changes (October 2025)

### ✅ Database Migration (Oct 27)
- Migrated from in-memory to PostgreSQL
- Added demo user: `demo` / `demo123`
- Auto-seed 10 Memphis test companies
- Background sync every 15 minutes

### ✅ Imperial Units (Oct 28)
- Changed from meters/km to feet/miles
- Proximity: 800 feet (was 250 meters)
- Created `distance.ts` utility module

### ✅ Route Stops Table (Oct 28)
- Added relational `route_stops` for analytics
- Maintains legacy JSONB for compatibility
- Unique constraint prevents duplicates
- Automatic route completion when all stops done

### ✅ Map UX Improvements (Oct 28)
- 14px company markers (was 10px)
- Green user location marker
- Bottom sheet panel (no backdrop)
- Scrollable "Add Stop" dialog (was limited to 4)

---

## Known Issues & Limitations

### Current Limitations
1. **No offline mode** - Requires internet for maps/API calls
2. **Foreground GPS only** - App must stay open during routes
3. **No user signup UI** - Admins create users via database
4. **HubSpot custom object setup required** - Falls back to Notes

### HubSpot Integration Issue
```
Error: "Unable to infer object type from: field_visits"
```
**Cause:** Custom `field_visits` object doesn't exist  
**Fix:** Create custom object in HubSpot (see `HUBSPOT_CUSTOM_OBJECT_SETUP.md`)  
**Impact:** None - app falls back to Notes gracefully

---

## Planned Features (Roadmap)

### 🎯 Phase 2: AI Voice Forms (In Planning)
**User Request:** Voice-to-text form filling after each stop

**Requirements:**
- Voice recording at each stop
- AI transcription (Whisper API: $0.006/min)
- Intelligent field parsing (GPT-4o: ~$0.001/form)
- Custom form fields per stop type
- Pipe data to HubSpot

**Estimated Cost:** ~$0.013 per stop (~1.3 cents)
- 10 reps × 5 stops/day × 22 days = **$14.30/month**

**Open Questions:**
- What form fields to collect?
- Real-time or post-recording transcription?
- Auto-fill vs. suggest-and-confirm?
- HubSpot destination (Notes, custom object, properties)?

### 🔮 Phase 3: Future Enhancements
- Offline mode with background sync
- Background geolocation (service workers)
- Admin UI for user management
- Role-based permissions (admin, manager, rep)
- AI route prioritization
- Voice-to-text notes
- Webhook-based real-time sync
- React Native mobile app
- Multi-company support (multiple HubSpot portals)

---

## Environment Setup

### Required Secrets
```bash
DATABASE_URL                                # PostgreSQL connection
HUBSPOT_API_KEY                            # Private App token
MAPBOX_TOKEN                               # Server-side geocoding
VITE_MAPBOX_TOKEN                          # Client-side maps
SESSION_SECRET                             # Cookie encryption
```

### Optional Secrets
```bash
HUBSPOT_FIELD_VISIT_ASSOCIATION_TYPE_ID    # Company association
```

### HubSpot Private App Scopes
- `crm.objects.companies.read`
- `crm.objects.custom.read`
- `crm.objects.custom.write`
- `crm.objects.owners.read` (optional)

---

## Deployment Options

### Replit Development (Current)
- Auto-managed PostgreSQL (Neon)
- Secret management via Replit Secrets
- One-click restart workflow
- `npm run dev` - Development server

### VM Production (Recommended)
- Self-hosted PostgreSQL
- `.env` file for secrets
- `npm run build` + `npm start`
- Nginx reverse proxy
- PM2 for process management
- See DEPLOYMENT.md for full guide

---

## File Structure

```
/
├── client/src/
│   ├── pages/
│   │   ├── login.tsx          # Username/password auth
│   │   ├── plan.tsx           # Route planning + map
│   │   ├── route.tsx          # Active route execution
│   │   └── summary.tsx        # Daily summary + CSV
│   ├── components/
│   │   ├── map-view.tsx       # Mapbox GL integration
│   │   ├── route-panel.tsx    # Stop list + check-ins
│   │   ├── proximity-alert.tsx # 800-foot alert
│   │   ├── add-stop-dialog.tsx # Add companies mid-route
│   │   └── ui/                # Shadcn components
│   ├── lib/
│   │   ├── api.ts             # TanStack Query hooks
│   │   ├── auth.tsx           # Auth context
│   │   ├── distance.ts        # Imperial unit utilities
│   │   └── queryClient.ts     # API client setup
│   └── App.tsx                # Router + providers
│
├── server/
│   ├── services/
│   │   ├── hubspot.ts         # HubSpot API integration
│   │   ├── mapbox.ts          # Geocoding + routing
│   │   ├── sync.ts            # Background company sync
│   │   ├── auth.ts            # Bcrypt password utils
│   │   └── geo.ts             # Distance calculations
│   ├── db.ts                  # PostgreSQL connection
│   ├── storage.ts             # Drizzle ORM queries
│   ├── routes.ts              # Express API routes
│   ├── seed-data.ts           # Demo data
│   └── index.ts               # Server entry point
│
├── shared/
│   └── schema.ts              # Drizzle schemas + Zod
│
├── .env.example               # Environment template
├── drizzle.config.ts          # Database config
├── package.json               # Dependencies
├── vite.config.ts             # Vite build config
├── PROJECT_CONTEXT.md         # This file
└── DEPLOYMENT.md              # VM deployment guide
```

---

## Important Implementation Notes

### PostgreSQL Connection
- Supports any PostgreSQL 12+ (standard, Neon, RDS, etc.)
- Uses standard `pg` driver for VM deployment
- Connection pooling (max 20, min 2)
- Auto-loads `.env` in production

### Mapbox Token Usage
- **MAPBOX_TOKEN** - Server-side (geocoding, routing)
- **VITE_MAPBOX_TOKEN** - Client-side (map display)
- Must be same value, different env vars for Vite

### Session Management
- Stored in PostgreSQL via `connect-pg-simple`
- 24-hour expiry (configurable)
- Secure cookies in production (HTTPS required)

### Distance Calculations
- Internal: meters (Mapbox/Turf.js)
- Display: feet/miles (conversion in `distance.ts`)
- Proximity: 800 feet = ~243.84 meters

---

## Testing Credentials

**Demo User:**
- Username: `demo`
- Password: `demo123`
- HubSpot Owner ID: None (sees all companies)

**Demo Companies:**
- 10 Memphis, TN locations
- Auto-seeded on first server start
- Geocoded via Mapbox

---

## Performance Benchmarks

**Route Planning:**
- 4-stop route: ~400ms (Mapbox API)
- Company search: ~100ms (PostgreSQL)
- Map render: <1s (213 markers)

**Background Sync:**
- 1,707 companies: ~60s (HubSpot pagination)
- Runs every 15 minutes
- Only geocodes new addresses

**Check-In:**
- Local save: ~150ms
- HubSpot write: ~300ms (async)
- Total user-facing: ~150ms

---

## Security Considerations

### Implemented
- ✅ Bcrypt password hashing (10 rounds)
- ✅ Session-based auth (not JWT)
- ✅ SQL injection prevention (Drizzle ORM)
- ✅ XSS prevention (React escaping)
- ✅ HTTPS required in production
- ✅ Secure cookie flags

### TODO
- ⏳ Rate limiting on auth endpoints
- ⏳ CSRF tokens for state-changing requests
- ⏳ Input validation on all endpoints
- ⏳ Role-based access control (RBAC)

---

## Support & Documentation

**External Docs:**
- [HubSpot Private Apps](https://developers.hubspot.com/docs/api/private-apps)
- [Mapbox Optimization API](https://docs.mapbox.com/api/navigation/optimization/)
- [Drizzle ORM](https://orm.drizzle.team/)
- [TanStack Query](https://tanstack.com/query/latest)

**Project Docs:**
- `HUBSPOT_CUSTOM_OBJECT_SETUP.md` - Custom object creation
- `design_guidelines.md` - UI/UX standards
- `DEPLOYMENT.md` - VM deployment guide

---

## Contact & Handoff Notes

**For New Developers:**
1. Read this document first
2. Check `replit.md` for latest updates
3. Review `shared/schema.ts` for data model
4. Test with demo credentials
5. Ask about AI voice feature if starting that work

**For Production Deployment:**
1. Use `.env.example` as template
2. Create PostgreSQL database
3. Run `npm run db:push` for schema
4. Add HubSpot API key
5. Configure Mapbox tokens
6. Set strong SESSION_SECRET
7. Enable HTTPS
8. Use PM2 for process management

---

**Document Version:** 1.0  
**Last Updated:** October 28, 2025  
**Status:** Ready for team handoff
