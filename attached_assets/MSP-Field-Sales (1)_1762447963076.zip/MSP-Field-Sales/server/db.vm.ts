// VM Deployment Version - Standard PostgreSQL
// Replace server/db.ts with this file when deploying to VM
// Instructions: mv server/db.vm.ts server/db.ts

import { Pool } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import * as schema from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// PostgreSQL connection pool configuration
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL,
  max: parseInt(process.env.DB_POOL_MAX || '20', 10),      // Maximum connections
  min: parseInt(process.env.DB_POOL_MIN || '2', 10),       // Minimum connections
  idleTimeoutMillis: parseInt(process.env.DB_POOL_IDLE_TIMEOUT || '30000', 10), // 30s
});

export const db = drizzle(pool, { schema });
