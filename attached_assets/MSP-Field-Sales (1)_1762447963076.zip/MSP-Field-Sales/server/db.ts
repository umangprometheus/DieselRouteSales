import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle({ client: pool, schema });

// NOTE FOR VM DEPLOYMENT:
// When deploying to a VM with standard PostgreSQL, replace this file with:
//
// import { Pool } from 'pg';
// import { drizzle } from 'drizzle-orm/node-postgres';
// import * as schema from "@shared/schema";
//
// export const pool = new Pool({ 
//   connectionString: process.env.DATABASE_URL,
//   max: parseInt(process.env.DB_POOL_MAX || '20', 10),
//   min: parseInt(process.env.DB_POOL_MIN || '2', 10),
//   idleTimeoutMillis: parseInt(process.env.DB_POOL_IDLE_TIMEOUT || '30000', 10),
// });
//
// export const db = drizzle(pool, { schema });
